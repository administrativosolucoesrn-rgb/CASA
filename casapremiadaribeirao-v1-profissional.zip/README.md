# CASAPREMIADARIBEIRAO - V1 Profissional

Projeto base com:
- site público da campanha
- painel admin privado
- criação/edição de campanha
- faixa de números configurável (ex.: 150 até 500)
- integração Pix Mercado Pago
- status visual: disponível, reservado e pago
- login do admin via senha em variável de ambiente

## Estrutura
- `backend/` API + autenticação + Mercado Pago + dados
- `frontend/` site público + painel admin

## Configuração rápida

### Backend
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```

### Frontend
Em outro terminal:
```bash
cd frontend
npm install
npm run dev
```

## URLs
- Site público: `http://localhost:5173`
- Painel admin: `http://localhost:5173/#/admin`

## Importante
- A senha do admin NÃO fica no código do frontend.
- Coloque a senha no `backend/.env`.
- Troque depois por uma senha nova que você não use em outros lugares.

## V1 entregue
- Campanha inicial: Air Fryer
- Site: CASAPREMIADARIBEIRAO
- Cores: branco, vermelho e dourado
- Preço: R$ 2,00
- Números: de 150 até 500

## Produção
Para produção real, o ideal é adicionar:
- banco de dados real
- upload de imagem em storage
- validação do webhook
- expiração automática de reservas
- HTTPS e domínio
- painel com relatório/exportação

